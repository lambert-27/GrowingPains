package model;
//GROWING PAINS - Mark Lambert - C00192497
//Reminder class - Will be implemented over the course of Summer '25

/**
 * Reminder class will hold all of the logic behind setting a watering reminder for a plant the Customer owns
 * Coming Summer 2025
 */
public class Reminder {

//    private Date date;
//    private Time time;
//    private String reminderType;
//    private int id;
    
	/**
	 * Constructs a new Reminder object
	 */
    public Reminder() {
    }


}